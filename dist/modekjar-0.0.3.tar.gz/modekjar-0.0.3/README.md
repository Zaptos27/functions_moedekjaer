# functions_moedekjaer
It is a function collection written primarylly by Mikkel Møller Mødekjær
